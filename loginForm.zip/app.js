
function validate(){
    let username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    let standardPass = password.toLowerCase();

    if(containNum(password)==false){
        alert("Password must have at least one digit!")
        return false;
    }
    localStorage.setItem('finalUsername',username);
    window.open("welcome.html");
}

function setUsername(userN){
    username = userN;
    alert(username);
}
function getUsername(){
    return username;
}

function containNum(str){
    return /[0-9]/.test(str)
}

function usernameValidation(input){
    // var regex = /[^0-9A-Za-z]/;
    var regex = /[^0-9A-Za-z#$&@^_*]/;
    input.value = input.value.replace(regex,"");
    
}

function passwordValidation(password){
    var regex = /[^0-9A-Za-z#$&@^_!%*()=+]/;
    password.value = password.value.replace(regex,"");
}



