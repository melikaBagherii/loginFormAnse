function myfunction(){
    let username = localStorage.getItem('finalUsername');
    document.getElementById("demo").innerHTML="username: " + username;
}